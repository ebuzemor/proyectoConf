-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         5.7.21-log - MySQL Community Server (GPL)
-- SO del servidor:              Win32
-- HeidiSQL Versión:             9.5.0.5293
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para confraise
DROP DATABASE IF EXISTS `confraise`;
CREATE DATABASE IF NOT EXISTS `confraise` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `confraise`;

-- Volcando estructura para tabla confraise.academic_degree
DROP TABLE IF EXISTS `academic_degree`;
CREATE TABLE IF NOT EXISTS `academic_degree` (
  `DegreeId` varchar(50) NOT NULL,
  `PersonId` varchar(50) DEFAULT NULL,
  `InstitutionId` varchar(50) DEFAULT NULL,
  `NameDegree` varchar(255) DEFAULT NULL,
  `BiographicalSum` text,
  PRIMARY KEY (`DegreeId`),
  KEY `fk_degree_person` (`PersonId`),
  KEY `fk_degree_institution` (`InstitutionId`),
  CONSTRAINT `fk_degree_institution` FOREIGN KEY (`InstitutionId`) REFERENCES `institution` (`InstitutionId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_degree_person` FOREIGN KEY (`PersonId`) REFERENCES `person` (`PersonId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.academic_degree: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `academic_degree` DISABLE KEYS */;
/*!40000 ALTER TABLE `academic_degree` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.address
DROP TABLE IF EXISTS `address`;
CREATE TABLE IF NOT EXISTS `address` (
  `AddressId` varchar(50) NOT NULL,
  `PersonId` varchar(50) DEFAULT NULL,
  `Street1` varchar(100) NOT NULL,
  `Street2` varchar(100) NOT NULL,
  `District` varchar(100) NOT NULL,
  `PostalCode` varchar(20) NOT NULL,
  `CityId` varchar(50) NOT NULL,
  PRIMARY KEY (`AddressId`),
  KEY `fk_address_person` (`PersonId`),
  CONSTRAINT `fk_address_person` FOREIGN KEY (`PersonId`) REFERENCES `person` (`PersonId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.address: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
/*!40000 ALTER TABLE `address` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.bank_information
DROP TABLE IF EXISTS `bank_information`;
CREATE TABLE IF NOT EXISTS `bank_information` (
  `InfoBankId` varchar(50) NOT NULL,
  `PersonId` varchar(50) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `AccountNumber` varchar(255) DEFAULT NULL,
  `VerifiedAccount` bit(1) DEFAULT NULL,
  PRIMARY KEY (`InfoBankId`),
  KEY `fk_bank_person` (`PersonId`),
  CONSTRAINT `fk_bank_person` FOREIGN KEY (`PersonId`) REFERENCES `person` (`PersonId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.bank_information: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `bank_information` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank_information` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.cities
DROP TABLE IF EXISTS `cities`;
CREATE TABLE IF NOT EXISTS `cities` (
  `CityId` varchar(50) NOT NULL,
  `StateId` varchar(50) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`CityId`),
  KEY `fk_city_state` (`StateId`),
  CONSTRAINT `fk_city_state` FOREIGN KEY (`StateId`) REFERENCES `states` (`StateId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.cities: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.conference
DROP TABLE IF EXISTS `conference`;
CREATE TABLE IF NOT EXISTS `conference` (
  `ConferenceId` varchar(50) NOT NULL,
  `FieldId` varchar(50) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `BriefSummary` text,
  `Location` varchar(255) DEFAULT NULL,
  `RegDeadline` datetime DEFAULT NULL,
  `Website` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ConferenceId`),
  KEY `FK_conference_fields` (`FieldId`),
  CONSTRAINT `FK_conference_fields` FOREIGN KEY (`FieldId`) REFERENCES `fields` (`FieldId`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.conference: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `conference` DISABLE KEYS */;
/*!40000 ALTER TABLE `conference` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.conference_dates
DROP TABLE IF EXISTS `conference_dates`;
CREATE TABLE IF NOT EXISTS `conference_dates` (
  `ConferenceDateId` varchar(50) NOT NULL,
  `ConferenceId` varchar(50) DEFAULT NULL,
  `ConferenceDate` datetime DEFAULT NULL,
  PRIMARY KEY (`ConferenceDateId`),
  KEY `FK_conference_dates_conference` (`ConferenceId`),
  CONSTRAINT `FK_conference_dates_conference` FOREIGN KEY (`ConferenceId`) REFERENCES `conference` (`ConferenceId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.conference_dates: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `conference_dates` DISABLE KEYS */;
/*!40000 ALTER TABLE `conference_dates` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.conference_sponsor
DROP TABLE IF EXISTS `conference_sponsor`;
CREATE TABLE IF NOT EXISTS `conference_sponsor` (
  `ConferenceSponsorId` varchar(50) NOT NULL,
  `ConferenceId` varchar(50) DEFAULT NULL,
  `NameSponsor` varchar(255) DEFAULT NULL,
  `Website` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ConferenceSponsorId`),
  KEY `FK_conference_sponsor_conference` (`ConferenceId`),
  CONSTRAINT `FK_conference_sponsor_conference` FOREIGN KEY (`ConferenceId`) REFERENCES `conference` (`ConferenceId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.conference_sponsor: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `conference_sponsor` DISABLE KEYS */;
/*!40000 ALTER TABLE `conference_sponsor` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.countries
DROP TABLE IF EXISTS `countries`;
CREATE TABLE IF NOT EXISTS `countries` (
  `CountryId` varchar(50) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`CountryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.countries: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.crowfunding_projects
DROP TABLE IF EXISTS `crowfunding_projects`;
CREATE TABLE IF NOT EXISTS `crowfunding_projects` (
  `CrowfundingId` varchar(50) NOT NULL,
  `SponsorshipId` varchar(50) DEFAULT NULL,
  `ProjectId` varchar(50) DEFAULT NULL,
  `SponsorTermsAccepted` bit(1) DEFAULT NULL,
  PRIMARY KEY (`CrowfundingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.crowfunding_projects: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `crowfunding_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `crowfunding_projects` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.currency
DROP TABLE IF EXISTS `currency`;
CREATE TABLE IF NOT EXISTS `currency` (
  `CurrencyId` varchar(50) NOT NULL,
  `CurrencyName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`CurrencyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.currency: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.currency_conversion
DROP TABLE IF EXISTS `currency_conversion`;
CREATE TABLE IF NOT EXISTS `currency_conversion` (
  `ConversionRateId` varchar(50) NOT NULL,
  `BaseCurrencyId` varchar(50) DEFAULT NULL,
  `TargetCurrencyId` varchar(50) DEFAULT NULL,
  `ConversionRate` decimal(10,2) DEFAULT NULL,
  `DateConversionRate` datetime DEFAULT NULL,
  PRIMARY KEY (`ConversionRateId`),
  KEY `FK_currency_conversion_currency` (`BaseCurrencyId`),
  KEY `FK_currency_conversion_currency_2` (`TargetCurrencyId`),
  CONSTRAINT `FK_currency_conversion_currency` FOREIGN KEY (`BaseCurrencyId`) REFERENCES `currency` (`CurrencyId`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_currency_conversion_currency_2` FOREIGN KEY (`TargetCurrencyId`) REFERENCES `currency` (`CurrencyId`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.currency_conversion: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `currency_conversion` DISABLE KEYS */;
/*!40000 ALTER TABLE `currency_conversion` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.details_expenses
DROP TABLE IF EXISTS `details_expenses`;
CREATE TABLE IF NOT EXISTS `details_expenses` (
  `DetailsExpenseId` varchar(50) NOT NULL,
  `ProjectId` varchar(50) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `AmountDetail` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`DetailsExpenseId`),
  KEY `FK_DetailsExpenses_project_started` (`ProjectId`),
  CONSTRAINT `FK_DetailsExpenses_project_started` FOREIGN KEY (`ProjectId`) REFERENCES `project_started` (`ProjectId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.details_expenses: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `details_expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `details_expenses` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.fields
DROP TABLE IF EXISTS `fields`;
CREATE TABLE IF NOT EXISTS `fields` (
  `FieldId` varchar(50) NOT NULL,
  `FieldName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`FieldId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.fields: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.hotel_info
DROP TABLE IF EXISTS `hotel_info`;
CREATE TABLE IF NOT EXISTS `hotel_info` (
  `HotelId` varchar(50) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `PhoneNumber` varchar(50) DEFAULT NULL,
  `Website` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`HotelId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.hotel_info: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `hotel_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `hotel_info` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.hotel_price
DROP TABLE IF EXISTS `hotel_price`;
CREATE TABLE IF NOT EXISTS `hotel_price` (
  `hotelPriceId` varchar(50) NOT NULL,
  `hotelId` varchar(50) DEFAULT NULL,
  `DescriptionPrice` varchar(100) DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL,
  `ExpirationDate` datetime DEFAULT NULL,
  PRIMARY KEY (`hotelPriceId`),
  KEY `FK_hotel_price_hotel_info` (`hotelId`),
  CONSTRAINT `FK_hotel_price_hotel_info` FOREIGN KEY (`hotelId`) REFERENCES `hotel_info` (`HotelId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.hotel_price: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `hotel_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `hotel_price` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.institution
DROP TABLE IF EXISTS `institution`;
CREATE TABLE IF NOT EXISTS `institution` (
  `InstitutionId` varchar(50) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Link` varchar(50) DEFAULT NULL,
  `CityId` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`InstitutionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.institution: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `institution` DISABLE KEYS */;
/*!40000 ALTER TABLE `institution` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.media_info
DROP TABLE IF EXISTS `media_info`;
CREATE TABLE IF NOT EXISTS `media_info` (
  `MediaInfoId` varchar(50) NOT NULL,
  `ProjectId` varchar(50) DEFAULT NULL,
  `DataMedia` blob,
  `TypeMedia` enum('Video','Photo') DEFAULT NULL,
  PRIMARY KEY (`MediaInfoId`),
  KEY `FK_media_info_project_started` (`ProjectId`),
  CONSTRAINT `FK_media_info_project_started` FOREIGN KEY (`ProjectId`) REFERENCES `project_started` (`ProjectId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.media_info: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `media_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_info` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla confraise.migrations: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
REPLACE INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_resets_table', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.password_resets
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla confraise.password_resets: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.payment_method
DROP TABLE IF EXISTS `payment_method`;
CREATE TABLE IF NOT EXISTS `payment_method` (
  `PaymentMethodId` varchar(50) NOT NULL,
  `Description` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`PaymentMethodId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.payment_method: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `payment_method` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_method` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.person
DROP TABLE IF EXISTS `person`;
CREATE TABLE IF NOT EXISTS `person` (
  `PersonId` varchar(50) NOT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `FirstName` varchar(100) DEFAULT NULL,
  `MiddleName` varchar(100) DEFAULT NULL,
  `LastName` varchar(100) DEFAULT NULL,
  `FullName` varchar(300) DEFAULT NULL,
  `Gender` varbinary(1) DEFAULT NULL,
  `Photo` blob,
  `IsEndorser` bit(1) DEFAULT NULL,
  `TermsAccepted` bit(1) DEFAULT NULL,
  PRIMARY KEY (`PersonId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.person: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
/*!40000 ALTER TABLE `person` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.phone
DROP TABLE IF EXISTS `phone`;
CREATE TABLE IF NOT EXISTS `phone` (
  `PhoneId` varchar(50) NOT NULL,
  `PersonId` varchar(50) DEFAULT NULL,
  `PhoneNumber` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`PhoneId`),
  KEY `fk_phone_person` (`PersonId`),
  CONSTRAINT `fk_phone_person` FOREIGN KEY (`PersonId`) REFERENCES `person` (`PersonId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.phone: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `phone` DISABLE KEYS */;
/*!40000 ALTER TABLE `phone` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.potential_sponsor
DROP TABLE IF EXISTS `potential_sponsor`;
CREATE TABLE IF NOT EXISTS `potential_sponsor` (
  `PotentialSponsorId` varchar(50) NOT NULL,
  `PersonId` varchar(50) DEFAULT NULL,
  `CompanyName` varchar(255) DEFAULT NULL,
  `FieldExpertise` varchar(255) DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `ConfirmedSponsor` bit(1) DEFAULT NULL,
  `Website` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`PotentialSponsorId`),
  KEY `FK_Potential_sponsor_person` (`PersonId`),
  CONSTRAINT `FK_Potential_sponsor_person` FOREIGN KEY (`PersonId`) REFERENCES `person` (`PersonId`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.potential_sponsor: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `potential_sponsor` DISABLE KEYS */;
/*!40000 ALTER TABLE `potential_sponsor` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.price_registration
DROP TABLE IF EXISTS `price_registration`;
CREATE TABLE IF NOT EXISTS `price_registration` (
  `PriceId` varchar(50) NOT NULL,
  `ConferenceId` varchar(50) DEFAULT NULL,
  `Category` varchar(100) DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`PriceId`),
  KEY `FK_price_registration_conference` (`ConferenceId`),
  CONSTRAINT `FK_price_registration_conference` FOREIGN KEY (`ConferenceId`) REFERENCES `conference` (`ConferenceId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.price_registration: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `price_registration` DISABLE KEYS */;
/*!40000 ALTER TABLE `price_registration` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.professional_info
DROP TABLE IF EXISTS `professional_info`;
CREATE TABLE IF NOT EXISTS `professional_info` (
  `InfoId` varchar(50) NOT NULL,
  `PersonId` varchar(50) DEFAULT NULL,
  `InstitutionId` varchar(50) DEFAULT NULL,
  `JobTitle` varchar(255) DEFAULT NULL,
  `InitialDate` datetime DEFAULT NULL,
  `EndDate` datetime DEFAULT NULL,
  `IsActualJob` bit(1) DEFAULT NULL,
  PRIMARY KEY (`InfoId`),
  KEY `fk_profesional_person` (`PersonId`),
  KEY `fk_profesional_institution` (`InstitutionId`),
  CONSTRAINT `fk_profesional_institution` FOREIGN KEY (`InstitutionId`) REFERENCES `institution` (`InstitutionId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_profesional_person` FOREIGN KEY (`PersonId`) REFERENCES `person` (`PersonId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.professional_info: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `professional_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `professional_info` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.project_started
DROP TABLE IF EXISTS `project_started`;
CREATE TABLE IF NOT EXISTS `project_started` (
  `ProjectId` varchar(50) NOT NULL,
  `PersonId` varchar(50) DEFAULT NULL,
  `ConversionRateId` varchar(50) DEFAULT NULL,
  `TypeSponsorFeedId` varchar(50) DEFAULT NULL,
  `OnlyAttendance` bit(1) DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `TypePresentation` varchar(50) DEFAULT NULL,
  `BriefSummary` text,
  `AbstractPresentation` text,
  `AmountRequested` decimal(10,2) DEFAULT NULL,
  `CampaignDays` int(11) DEFAULT NULL,
  `AnimalsInvolved` bit(1) DEFAULT NULL,
  `TermsAccepted` bit(1) DEFAULT NULL,
  `IsInternational` bit(1) DEFAULT NULL,
  PRIMARY KEY (`ProjectId`),
  KEY `FK_project_started_person` (`PersonId`),
  KEY `FK_project_started_currency_conversion` (`ConversionRateId`),
  CONSTRAINT `FK_project_started_currency_conversion` FOREIGN KEY (`ConversionRateId`) REFERENCES `currency_conversion` (`ConversionRateId`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_project_started_person` FOREIGN KEY (`PersonId`) REFERENCES `person` (`PersonId`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.project_started: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `project_started` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_started` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.publication
DROP TABLE IF EXISTS `publication`;
CREATE TABLE IF NOT EXISTS `publication` (
  `DOI` varchar(100) NOT NULL,
  `PersonId` varchar(50) DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `JournalName` varchar(255) DEFAULT NULL,
  `Year` int(11) DEFAULT NULL,
  `Authors` varchar(255) DEFAULT NULL,
  `Link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`DOI`),
  KEY `fk_publication_person` (`PersonId`),
  CONSTRAINT `fk_publication_person` FOREIGN KEY (`PersonId`) REFERENCES `person` (`PersonId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.publication: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `publication` DISABLE KEYS */;
/*!40000 ALTER TABLE `publication` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.remuneration
DROP TABLE IF EXISTS `remuneration`;
CREATE TABLE IF NOT EXISTS `remuneration` (
  `RemuneratioinId` varchar(50) NOT NULL,
  `SponsorShipId` varchar(50) DEFAULT NULL,
  `TypeRemunerationId` varchar(50) DEFAULT NULL,
  `AmountRemuneration` decimal(10,2) DEFAULT NULL,
  `SpecialRequest` text,
  `MeetSalesRep` bit(1) DEFAULT NULL,
  `TermsAccepted` bit(1) DEFAULT NULL,
  PRIMARY KEY (`RemuneratioinId`),
  KEY `FK_remuneration_type_remuneration` (`TypeRemunerationId`),
  KEY `FK_remuneration_sponsor_info` (`SponsorShipId`),
  CONSTRAINT `FK_remuneration_sponsor_info` FOREIGN KEY (`SponsorShipId`) REFERENCES `sponsor_info` (`SponsorId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_remuneration_type_remuneration` FOREIGN KEY (`TypeRemunerationId`) REFERENCES `type_remuneration` (`TypeRemunerationId`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.remuneration: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `remuneration` DISABLE KEYS */;
/*!40000 ALTER TABLE `remuneration` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.selected_conferences
DROP TABLE IF EXISTS `selected_conferences`;
CREATE TABLE IF NOT EXISTS `selected_conferences` (
  `SelectedConfId` varchar(50) NOT NULL,
  `SponsorshipId` varchar(50) DEFAULT NULL,
  `ConferenceId` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`SelectedConfId`),
  KEY `FK_selected_conferences_sponsorship` (`SponsorshipId`),
  KEY `FK_selected_conferences_conference` (`ConferenceId`),
  CONSTRAINT `FK_selected_conferences_conference` FOREIGN KEY (`ConferenceId`) REFERENCES `conference` (`ConferenceId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_selected_conferences_sponsorship` FOREIGN KEY (`SponsorshipId`) REFERENCES `sponsorship` (`SponsorShipId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.selected_conferences: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `selected_conferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `selected_conferences` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.selected_projects
DROP TABLE IF EXISTS `selected_projects`;
CREATE TABLE IF NOT EXISTS `selected_projects` (
  `SelectedNumProjectId` varchar(50) NOT NULL,
  `SponsorshipId` varchar(50) DEFAULT NULL,
  `ProjectId` varchar(50) DEFAULT NULL,
  `SponsorTermsAccepted` bit(1) DEFAULT NULL,
  PRIMARY KEY (`SelectedNumProjectId`),
  KEY `FK_selected_projects_sponsorship` (`SponsorshipId`),
  KEY `FK_selected_projects_project_started` (`ProjectId`),
  CONSTRAINT `FK_selected_projects_project_started` FOREIGN KEY (`ProjectId`) REFERENCES `project_started` (`ProjectId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_selected_projects_sponsorship` FOREIGN KEY (`SponsorshipId`) REFERENCES `sponsorship` (`SponsorShipId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.selected_projects: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `selected_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `selected_projects` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.speaker
DROP TABLE IF EXISTS `speaker`;
CREATE TABLE IF NOT EXISTS `speaker` (
  `SpeakerId` varchar(50) NOT NULL,
  `FirstName` varchar(100) DEFAULT NULL,
  `LastName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`SpeakerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.speaker: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `speaker` DISABLE KEYS */;
/*!40000 ALTER TABLE `speaker` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.speaker_conference
DROP TABLE IF EXISTS `speaker_conference`;
CREATE TABLE IF NOT EXISTS `speaker_conference` (
  `SpeakerConfId` varchar(50) NOT NULL,
  `SpeakerId` varchar(50) NOT NULL,
  `ConferenceId` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`SpeakerConfId`),
  KEY `FK_FeaturedSpeaker_conference` (`ConferenceId`),
  KEY `FK_speaker_conference_speaker` (`SpeakerId`),
  CONSTRAINT `FK_FeaturedSpeaker_conference` FOREIGN KEY (`ConferenceId`) REFERENCES `conference` (`ConferenceId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_speaker_conference_speaker` FOREIGN KEY (`SpeakerId`) REFERENCES `speaker` (`SpeakerId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.speaker_conference: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `speaker_conference` DISABLE KEYS */;
/*!40000 ALTER TABLE `speaker_conference` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.sponsorship
DROP TABLE IF EXISTS `sponsorship`;
CREATE TABLE IF NOT EXISTS `sponsorship` (
  `SponsorShipId` varchar(50) NOT NULL,
  `SponsorId` varchar(50) DEFAULT NULL,
  `PaymentMethodId` varchar(50) DEFAULT NULL,
  `AmountFunding` decimal(10,2) DEFAULT NULL,
  `NumbersProject` int(11) DEFAULT NULL,
  `DateDeadLine` datetime DEFAULT NULL,
  PRIMARY KEY (`SponsorShipId`),
  KEY `FK_sponsorship_sponsor_info` (`SponsorId`),
  KEY `FK_sponsorship_payment_method` (`PaymentMethodId`),
  CONSTRAINT `FK_sponsorship_payment_method` FOREIGN KEY (`PaymentMethodId`) REFERENCES `payment_method` (`PaymentMethodId`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_sponsorship_sponsor_info` FOREIGN KEY (`SponsorId`) REFERENCES `sponsor_info` (`SponsorId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.sponsorship: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `sponsorship` DISABLE KEYS */;
/*!40000 ALTER TABLE `sponsorship` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.sponsorship_fees
DROP TABLE IF EXISTS `sponsorship_fees`;
CREATE TABLE IF NOT EXISTS `sponsorship_fees` (
  `SponsorshipFeeId` varchar(50) NOT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `FeePercentageValue` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`SponsorshipFeeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.sponsorship_fees: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `sponsorship_fees` DISABLE KEYS */;
/*!40000 ALTER TABLE `sponsorship_fees` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.sponsor_info
DROP TABLE IF EXISTS `sponsor_info`;
CREATE TABLE IF NOT EXISTS `sponsor_info` (
  `SponsorId` varchar(50) NOT NULL,
  `CompanyName` varchar(255) DEFAULT NULL,
  `FieldActivity` text,
  `Website` varchar(255) DEFAULT NULL,
  `TermsAccepted` bit(1) DEFAULT NULL,
  PRIMARY KEY (`SponsorId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.sponsor_info: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `sponsor_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `sponsor_info` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.sponsor_representative
DROP TABLE IF EXISTS `sponsor_representative`;
CREATE TABLE IF NOT EXISTS `sponsor_representative` (
  `SponsorRepveId` varchar(50) NOT NULL,
  `SponsorId` varchar(50) DEFAULT NULL,
  `PersonId` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`SponsorRepveId`),
  KEY `FK_sponsor_representative_sponsor_info` (`SponsorId`),
  KEY `FK_sponsor_representative_person` (`PersonId`),
  CONSTRAINT `FK_sponsor_representative_person` FOREIGN KEY (`PersonId`) REFERENCES `person` (`PersonId`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_sponsor_representative_sponsor_info` FOREIGN KEY (`SponsorId`) REFERENCES `sponsor_info` (`SponsorId`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.sponsor_representative: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `sponsor_representative` DISABLE KEYS */;
/*!40000 ALTER TABLE `sponsor_representative` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.states
DROP TABLE IF EXISTS `states`;
CREATE TABLE IF NOT EXISTS `states` (
  `StateId` varchar(50) NOT NULL,
  `CountryId` varchar(50) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`StateId`),
  KEY `fk_state_country` (`CountryId`),
  CONSTRAINT `fk_state_country` FOREIGN KEY (`CountryId`) REFERENCES `countries` (`CountryId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.states: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
/*!40000 ALTER TABLE `states` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.submitted_conferences
DROP TABLE IF EXISTS `submitted_conferences`;
CREATE TABLE IF NOT EXISTS `submitted_conferences` (
  `SubmitConferenceId` varchar(50) NOT NULL,
  `ProjectId` varchar(50) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Website` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`SubmitConferenceId`),
  KEY `FK_submitted_conferences_project_started` (`ProjectId`),
  CONSTRAINT `FK_submitted_conferences_project_started` FOREIGN KEY (`ProjectId`) REFERENCES `project_started` (`ProjectId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.submitted_conferences: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `submitted_conferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `submitted_conferences` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.type_remuneration
DROP TABLE IF EXISTS `type_remuneration`;
CREATE TABLE IF NOT EXISTS `type_remuneration` (
  `TypeRemunerationId` varchar(50) NOT NULL,
  `Description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`TypeRemunerationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla confraise.type_remuneration: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `type_remuneration` DISABLE KEYS */;
/*!40000 ALTER TABLE `type_remuneration` ENABLE KEYS */;

-- Volcando estructura para tabla confraise.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `iduser` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idpersona` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`iduser`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla confraise.users: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
REPLACE INTO `users` (`iduser`, `idpersona`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
	(3, '8a995a00-c799-11e8-857a-51d53b63faca', 'delbicasltric@gmail.com', '$2y$10$6.kXh9vA/yqEc7C1oF9VJe1LGW6B1bySqBXNGFbmsXNiM67Nl9H5.', NULL, '2018-10-04 05:51:30', '2018-10-04 05:51:30'),
	(4, 'b4057220-c799-11e8-81d1-cd15745de30f', 'delbicqaltric@gmail.com', '$2y$10$65RbS33Qm6BPJXYpZY/KgeJBq52Bw45pK17GM6vS4aJWhIM6HUJXW', NULL, '2018-10-04 05:52:39', '2018-10-04 05:52:39'),
	(5, 'efb919c0-c799-11e8-b1c6-ffdb1a5e35ce', 'delbicaltric@gmail.com', '$2y$10$AgXMrQCI9fMF0ivPbXRYAOKdRXq.vRCd7XrHogvdAADTqozZzG1em', NULL, '2018-10-04 05:54:20', '2018-10-04 05:54:20');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
